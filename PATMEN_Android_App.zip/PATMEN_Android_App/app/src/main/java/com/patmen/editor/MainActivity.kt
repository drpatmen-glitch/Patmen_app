package com.patmen.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private var original: Bitmap? = null
    private var current: Bitmap? = null
    private var userText = ""
    private var filter = 0
    private var watermark = true

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadPhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 19, 29)
        window.navigationBarColor = Color.rgb(16, 19, 29)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(16, 19, 29))
        }

        val header = TextView(this).apply {
            text = "👑 PATMEN"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(236, 194, 91))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(44)))

        val sub = TextView(this).apply {
            text = "PHOTO EDITOR  •  Edit · Create · Be Unique"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, dp(28)))

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(27, 33, 47))
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "PATMEN photo preview"
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "ستاسو عکسونه، ستاسو سټایل • PATMEN"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.rgb(236, 194, 91))
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(status)

        addButtonRow(root, "عکس انتخاب کړه", "متن ولیکه") {
            if (it == 0) pickPhoto.launch("image/*") else addText()
        }
        addButtonRow(root, "فلټرونه", "PATMEN نښه") {
            if (it == 0) chooseFilter() else {
                watermark = !watermark
                refresh()
                toast(if (watermark) "PATMEN نښه فعاله ده" else "PATMEN نښه بنده ده")
            }
        }
        addButtonRow(root, "عکس خوندي کړه", "WhatsApp ته شریک کړه") {
            if (it == 0) savePhoto() else shareWhatsApp()
        }
        val share = makeButton("نور ځایونه شریکول") { shareGeneric() }
        root.addView(share, LinearLayout.LayoutParams(-1, dp(48)))
        val footer = TextView(this).apply {
            text = "👑 PATMEN • Your photo, your style"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.rgb(236, 194, 91))
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun addButtonRow(parent: LinearLayout, left: String, right: String, action: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(makeButton(left) { action(0) }, weighted())
        row.addView(makeButton(right) { action(1) }, weighted())
        parent.addView(row)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(48, 57, 78))
        setOnClickListener { action() }
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
        setMargins(dp(3), dp(3), dp(3), dp(3))
    }

    private fun loadPhoto(uri: Uri) {
        try {
            val bitmap = if (Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.isMutableRequired = false }
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
            original = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            userText = ""
            filter = 0
            refresh()
            status.text = "عکس چمتو دی • PATMEN"
        } catch (_: Exception) {
            toast("عکس پرانیستل نه شو.")
        }
    }

    private fun addText() {
        if (original == null) { toast("لومړی عکس انتخاب کړه."); return }
        val input = EditText(this).apply {
            hint = "PATMEN یا خپل متن ولیکه"
            setText(userText)
        }
        AlertDialog.Builder(this)
            .setTitle("پر عکس متن — PATMEN")
            .setView(input)
            .setPositiveButton("تطبیق") { _, _ ->
                userText = input.text.toString()
                refresh()
            }
            .setNegativeButton("بندول", null)
            .show()
    }

    private fun chooseFilter() {
        if (original == null) { toast("لومړی عکس انتخاب کړه."); return }
        val names = arrayOf("اصلي عکس", "تور او سپین", "ګرم رنګ", "سوړ رنګ")
        AlertDialog.Builder(this)
            .setTitle("د PATMEN فلټرونه")
            .setItems(names) { _, which -> filter = which; refresh() }
            .show()
    }

    private fun render(): Bitmap? {
        val src = original ?: return null
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        when (filter) {
            1 -> paint.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
            2 -> paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                1.10f,0f,0f,0f,8f, 0f,1.03f,0f,0f,3f, 0f,0f,0.90f,0f,0f, 0f,0f,0f,1f,0f
            )))
            3 -> paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                0.92f,0f,0f,0f,0f, 0f,1.01f,0f,0f,0f, 0f,0f,1.12f,0f,8f, 0f,0f,0f,1f,0f
            )))
        }
        canvas.drawBitmap(src, 0f, 0f, paint)

        if (userText.isNotBlank() || watermark) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                textSize = (src.width * 0.065f).coerceIn(26f, 100f)
                setShadowLayer(src.width * 0.008f, 2f, 3f, Color.BLACK)
            }
            if (userText.isNotBlank()) canvas.drawText(userText, src.width / 2f, src.height * 0.86f, p)
            if (watermark) {
                p.color = Color.rgb(236, 194, 91)
                p.textSize = (src.width * 0.038f).coerceIn(18f, 52f)
                canvas.drawText("👑 PATMEN", src.width / 2f, src.height * 0.95f, p)
            }
        }
        return out
    }

    private fun refresh() {
        current = render()
        if (current != null) preview.setImageBitmap(current)
    }

    private fun savePhoto() {
        val bitmap = render() ?: run { toast("لومړی عکس انتخاب کړه."); return }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PATMEN_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PATMEN")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("No image URI")
            contentResolver.openOutputStream(uri).use { stream ->
                if (stream == null) throw Exception("No output stream")
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            toast("عکس خوندي شو: Pictures/PATMEN")
        } catch (_: Exception) { toast("عکس خوندي نه شو؛ بیا هڅه وکړه.") }
    }

    private fun shareWhatsApp() {
        val uri = saveTempForSharing() ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            setPackage("com.whatsapp")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(intent) }
        catch (_: Exception) { toast("WhatsApp نصب نه دی یا شریکول ممکن نه شول.") }
    }

    private fun shareGeneric() {
        val uri = saveTempForSharing() ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "د PATMEN عکس شریک کړه"))
    }

    private fun saveTempForSharing(): Uri? {
        val bitmap = render() ?: run { toast("لومړی عکس انتخاب کړه."); return null }
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PATMEN_share_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PATMEN")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri).use { stream ->
                if (stream == null) return null
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            uri
        } catch (_: Exception) { toast("د شریکولو لپاره عکس چمتو نه شو."); null }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
