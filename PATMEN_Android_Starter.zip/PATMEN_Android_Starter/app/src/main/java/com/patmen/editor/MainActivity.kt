package com.patmen.editor

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.OutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private var originalBitmap: Bitmap? = null
    private var editedBitmap: Bitmap? = null
    private var overlayText: String = ""
    private var filterMode = 0

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { loadImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 19, 29)
        window.navigationBarColor = Color.rgb(16, 19, 29)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(16))
            setBackgroundColor(Color.rgb(16, 19, 29))
        }

        val brand = TextView(this).apply {
            text = "👑 PATMEN PHOTO EDITOR"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(236, 194, 91))
            setPadding(0, dp(8), 0, dp(12))
        }
        page.addView(brand, LinearLayout.LayoutParams(-1, -2))

        val tagline = TextView(this).apply {
            text = "Edit • Create • Be Unique"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(12))
        }
        page.addView(tagline)

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(31, 37, 51))
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "Photo preview"
        }
        page.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(actionButton("Choose photo") { pickImage.launch("image/*") }, weighted())
        row1.addView(actionButton("Add text") { askForText() }, weighted())
        page.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(actionButton("Filters") { chooseFilter() }, weighted())
        row2.addView(actionButton("Save") { saveImage() }, weighted())
        page.addView(row2)

        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(actionButton("Share") { shareImage() }, weighted())
        row3.addView(actionButton("WhatsApp") { shareToWhatsApp() }, weighted())
        page.addView(row3)

        val note = TextView(this).apply {
            text = "PATMEN • Your photo, your style"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(12), 0, 0)
        }
        page.addView(note)
        setContentView(page)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 57, 78)))
            setOnClickListener { action() }
            layoutParams = weighted()
        }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(52), 1f).apply {
        setMargins(dp(4), dp(5), dp(4), dp(5))
    }

    private fun loadImage(uri: Uri) {
        try {
            val bitmap = if (android.os.Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.isMutableRequired = false }
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
            originalBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            overlayText = ""
            filterMode = 0
            refreshPreview()
        } catch (e: Exception) {
            toast("Could not open this image.")
        }
    }

    private fun askForText() {
        if (originalBitmap == null) {
            toast("Choose a photo first.")
            return
        }
        val input = EditText(this).apply {
            hint = "Write PATMEN or your own text"
            setText(overlayText)
        }
        AlertDialog.Builder(this)
            .setTitle("Add text")
            .setView(input)
            .setPositiveButton("Apply") { _, _ ->
                overlayText = input.text.toString()
                refreshPreview()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseFilter() {
        if (originalBitmap == null) {
            toast("Choose a photo first.")
            return
        }
        val options = arrayOf("Original", "Black & white", "Warm", "Cool")
        AlertDialog.Builder(this)
            .setTitle("Choose a filter")
            .setItems(options) { _, which ->
                filterMode = which
                refreshPreview()
            }.show()
    }

    private fun makeEditedBitmap(): Bitmap? {
        val src = originalBitmap ?: return null
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        when (filterMode) {
            1 -> {
                val matrix = ColorMatrix().apply { setSaturation(0f) }
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            2 -> {
                val matrix = ColorMatrix(floatArrayOf(
                    1.12f, 0f, 0f, 0f, 10f,
                    0f, 1.03f, 0f, 0f, 3f,
                    0f, 0f, 0.88f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            3 -> {
                val matrix = ColorMatrix(floatArrayOf(
                    0.90f, 0f, 0f, 0f, 0f,
                    0f, 1.02f, 0f, 0f, 0f,
                    0f, 0f, 1.12f, 0f, 8f,
                    0f, 0f, 0f, 1f, 0f
                ))
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
        }
        canvas.drawBitmap(src, 0f, 0f, paint)

        if (overlayText.isNotBlank()) {
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                textSize = (src.width * 0.075f).coerceIn(28f, 110f)
                typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                setShadowLayer(src.width * 0.008f, 2f, 3f, Color.BLACK)
            }
            val x = src.width / 2f
            val y = src.height * 0.90f
            canvas.drawText(overlayText, x, y, textPaint)
            // Small brand signature
            textPaint.textSize = (src.width * 0.035f).coerceIn(18f, 48f)
            textPaint.color = Color.rgb(236, 194, 91)
            canvas.drawText("👑 PATMEN", x, src.height * 0.96f, textPaint)
        }
        return out
    }

    private fun refreshPreview() {
        editedBitmap = makeEditedBitmap()
        preview.setImageBitmap(editedBitmap)
    }

    private fun saveImage() {
        val bitmap = makeEditedBitmap()
        if (bitmap == null) {
            toast("Choose a photo first.")
            return
        }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PATMEN_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PATMEN")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Could not create image")
            contentResolver.openOutputStream(uri).use { stream: OutputStream? ->
                if (stream == null) throw Exception("Could not write image")
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            toast("Saved in Pictures/PATMEN")
        } catch (e: Exception) {
            toast("Save failed. Please try again.")
        }
    }

    private fun shareImage() {
        val uri = createShareUri() ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share PATMEN image"))
    }

    private fun shareToWhatsApp() {
        val uri = createShareUri() ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            setPackage("com.whatsapp")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("WhatsApp is not installed, or sharing is unavailable.")
        }
    }

    private fun createShareUri(): Uri? {
        val bitmap = makeEditedBitmap()
        if (bitmap == null) {
            toast("Choose a photo first.")
            return null
        }
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PATMEN_share_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PATMEN")
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri).use { stream ->
                if (stream == null) return null
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            uri
        } catch (e: Exception) {
            toast("Could not prepare image to share.")
            null
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
